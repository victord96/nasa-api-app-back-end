
package com.example.prueba_java.databinding;

import java.util.List;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "2022-07-08"
})
@Generated("jsonschema2pojo")
public class NearEarthObjects {

    @JsonProperty("2022-07-08")
    public List<com.example.prueba_java.databinding._20220708> _20220708 = null;

}
